﻿using System;

namespace Presentation
{
    public class Class1
    {
    }
}
