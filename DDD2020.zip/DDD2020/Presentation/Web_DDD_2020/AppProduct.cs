﻿namespace Web_DDD_2020
{
    internal class AppProduct2
    {
    }
}